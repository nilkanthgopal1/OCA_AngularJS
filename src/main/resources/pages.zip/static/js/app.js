var myApp=angular.module('myApp',['ngRoute','ngSanitize']);
myApp.config(function ($routeProvider,$locationProvider) {
        $locationProvider.hashPrefix('');
    
        $routeProvider.when('/userprofile',{
        templateUrl:'userprofile.html',
        controller:'userprofileController'
       /* css:'profileupdate.css'*/
    })
    $routeProvider.when('/updateprofile',{
        templateUrl:'updateprofile.html',
        controller:'updateprofileController'
        
    })
    $routeProvider.when('/sapage',{
        templateUrl:'sapage.html',
        
    })
    $routeProvider.when('/changepassword',{
        templateUrl:'changepassword.html'
       
    })
    $routeProvider.when('/planusage',{
        templateUrl:'planusage.html'
       
    })
    $routeProvider.when('/plansprice',{
        templateUrl:'planspricing.html'
        
    })
    $routeProvider.when('/',{
        templateUrl:'userprofile.html'
      
    }).otherwise({
        redirectTo : 'welcome.html'
    });
});

myApp.controller('userprofileController',['$scope','$http',function($scope,$http){
	
	console.log("userprofileController");
	console.log($scope);
	$scope.init=function(){
		 
		    $http({
		        method: 'GET',
		        url: 'http://localhost:8081//customerprofile',
		        params: {email: 'om@gmail.com'}
		     }).then(function (response){
		    	 console.log(response);
		    	 $scope.obj=response.data;
		    	 console.log("Obj values")
		    	 console.log($scope.obj);
		    	// var obj= JSON.parse(JSON.stringify(response.data));
		    	// $scope.arr=[];
		    	 
		    	/*angular.forEach(obj, function(value, key){
		    	     
		    	     if(key=='first_name' || key=='last_name' || key=='email_id' || key=='contact_no' || key=='country')
		    	     {
		    	    	 //console.log(key + ': ' + value);
		    	
		    	    	
		    	     }
		    	     
		    	});*/
		    	//console.log(arr);
		    	
		     },function (error){

		    	 console.log(error);
		     });
	}

}]);



myApp.controller('updateprofileController',['$scope','$http',function($scope,$http){
	
	console.log("updateprofileController");
	$scope.init=function(){
		 
		    $http({
		        method: 'GET',
		        url: 'http://localhost:8081//customerprofile',
		        params: {email: 'om@gmail.com'}
		     }).then(function (response){
		    	 console.log(response);
		    	 $scope.firstname=response.data.first_name;
		    	 $scope.lastname=response.data.last_name;
		    	 $scope.email=response.data.email_id;
		    	 $scope.mobile=response.data.contact_no;
		    	
		     },function (error){

		    	 console.log(error);
		     });
		   
		    
		    
		    $http({
		        method: 'GET',
		        url: 'http://localhost:8081//getCountries'
		     }).then(function (d){
		    	 console.log(d);
		    	 $scope.countrylist=d.data;
		     },function (error){

		    	 console.log(error);
		     });

	}
	 $scope.submitUpdateProfile=function(){
			console.log("In click function");
			console.log($scope.country);
			
			 $http({
			        method: 'POST',
			        url: 'http://localhost:8081//updateprofile',
			        //params: {firstname:$scope.firstname,lastname:$scope.lastname,email:$scope.email,contact:$scope.mobile}
			        data: {
			        	'firstname':$scope.firstname,'lastname':$scope.lastname,'email':$scope.email,'mobile':$scope.mobile,
			        	'country':$scope.country},
			        headers: {'Content-Type': 'application/json'}    
			 }).then(function (response){
			    	 console.log(response);
			    	 $scope.msg=response.data.msg;
			    	
			     },function (error){

			    	 console.log(error);
			     });
			   
		}
	
}]);